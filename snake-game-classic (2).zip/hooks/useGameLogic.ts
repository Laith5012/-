import { useState, useEffect, useCallback } from 'react';
import { Position, Direction, GameState, SnakeSegment, Food, DifficultyLevel, GameConfig } from '../types';
import {
  INITIAL_DIRECTION,
  HIGH_SCORE_STORAGE_KEY,
  ARROW_KEYS_MAP,
  MIN_SPEED,
  DIFFICULTY_SETTINGS_MAP,
  DEFAULT_DIFFICULTY,
  DEFAULT_PRESET_BOARD_SIZE,
} from '../constants';

const calculateInitialSnakePosition = (currentBoardSize: number): SnakeSegment[] => {
  const yPos = Math.floor(currentBoardSize / 2);
  return [
    { x: Math.floor(currentBoardSize / 2) + 1, y: yPos },
    { x: Math.floor(currentBoardSize / 2), y: yPos },
    { x: Math.floor(currentBoardSize / 2) - 1, y: yPos },
  ];
};

const generateRandomFoodPosition = (snake: SnakeSegment[], currentBoardSize: number, obstacles: Position[]): Food => {
  let newFoodPosition: Food;
  do {
    newFoodPosition = {
      x: Math.floor(Math.random() * currentBoardSize),
      y: Math.floor(Math.random() * currentBoardSize),
    };
  } while (
    snake.some(segment => segment.x === newFoodPosition.x && segment.y === newFoodPosition.y) ||
    obstacles.some(obstacle => obstacle.x === newFoodPosition.x && obstacle.y === newFoodPosition.y)
  );
  return newFoodPosition;
};

export interface StartGameParams {
  difficulty: DifficultyLevel;
  customBoardSize?: number;
  customInitialSpeed?: number;
}

export const useGameLogic = () => {
  const [currentConfig, setCurrentConfig] = useState<GameConfig>(() => ({
      ...DIFFICULTY_SETTINGS_MAP[DEFAULT_DIFFICULTY],
      boardSize: DEFAULT_PRESET_BOARD_SIZE, // Initial default board size
  }));
  const [snakeSegments, setSnakeSegments] = useState<SnakeSegment[]>(calculateInitialSnakePosition(currentConfig.boardSize));
  const [foodPosition, setFoodPosition] = useState<Food>(() => generateRandomFoodPosition(snakeSegments, currentConfig.boardSize, []));
  const [direction, setDirection] = useState<Direction>(INITIAL_DIRECTION);
  const [pendingDirection, setPendingDirection] = useState<Direction | null>(null);
  const [gameState, setGameState] = useState<GameState>(GameState.NotStarted);
  const [score, setScore] = useState<number>(0);
  const [highScore, setHighScore] = useState<number>(() => {
    const storedHighScore = localStorage.getItem(HIGH_SCORE_STORAGE_KEY);
    return storedHighScore ? parseInt(storedHighScore, 10) : 0;
  });
  // gameSpeed is part of currentConfig.initialSpeed now, setGameSpeed removed
  
  const [gameLevel, setGameLevel] = useState<number>(1);
  const [obstacles, setObstacles] = useState<Position[]>([]);
  const [isTransitioningLevel, setIsTransitioningLevel] = useState<boolean>(false);
  const [transitionTimeoutId, setTransitionTimeoutId] = useState<ReturnType<typeof setTimeout> | null>(null);


  const internalResetGame = useCallback((config: GameConfig) => {
    setCurrentConfig(config);
    setSnakeSegments(calculateInitialSnakePosition(config.boardSize));
    setDirection(INITIAL_DIRECTION);
    setPendingDirection(null);
    setScore(0);
    // gameSpeed is now config.initialSpeed
    setGameLevel(1);
    setObstacles([]); // Obstacles determined by config and level
    setIsTransitioningLevel(false);
    if (transitionTimeoutId) clearTimeout(transitionTimeoutId);
    setFoodPosition(generateRandomFoodPosition(calculateInitialSnakePosition(config.boardSize), config.boardSize, []));
  }, [transitionTimeoutId]);

  const startGame = useCallback(({ difficulty, customBoardSize, customInitialSpeed }: StartGameParams) => {
    const baseSettings = DIFFICULTY_SETTINGS_MAP[difficulty];
    const resolvedBoardSize = customBoardSize ?? DEFAULT_PRESET_BOARD_SIZE;
    const resolvedInitialSpeed = customInitialSpeed ?? baseSettings.initialSpeed;

    const isCustom = customBoardSize !== undefined || customInitialSpeed !== undefined;
    
    const newConfig: GameConfig = {
      ...baseSettings,
      initialSpeed: resolvedInitialSpeed,
      boardSize: resolvedBoardSize,
      levelName: isCustom ? `${baseSettings.levelName} (Custom)` : baseSettings.levelName,
      // Obstacles only apply if using the default preset board size for which they are defined
      obstaclePositions: resolvedBoardSize === DEFAULT_PRESET_BOARD_SIZE ? baseSettings.obstaclePositions : [],
      scoreToReachLevel2: resolvedBoardSize === DEFAULT_PRESET_BOARD_SIZE ? baseSettings.scoreToReachLevel2 : Infinity,
    };
    
    internalResetGame(newConfig);
    setGameState(GameState.Playing);
  }, [internalResetGame]);

  const pauseGame = useCallback(() => {
    if (gameState === GameState.Playing && !isTransitioningLevel) {
      setGameState(GameState.Paused);
    }
  }, [gameState, isTransitioningLevel]);

  const resumeGame = useCallback(() => {
    if (gameState === GameState.Paused && !isTransitioningLevel) {
      setGameState(GameState.Playing);
    }
  }, [gameState, isTransitioningLevel]);

  const updateHighScore = useCallback(() => {
    if (score > highScore) {
      setHighScore(score);
      localStorage.setItem(HIGH_SCORE_STORAGE_KEY, score.toString());
    }
  }, [score, highScore]);

  const moveSnake = useCallback(() => {
    if (gameState !== GameState.Playing || isTransitioningLevel) return;

    let currentMoveDirection = direction;
    if (pendingDirection !== null) {
        const isOppositeDirection =
            (direction === Direction.UP && pendingDirection === Direction.DOWN) ||
            (direction === Direction.DOWN && pendingDirection === Direction.UP) ||
            (direction === Direction.LEFT && pendingDirection === Direction.RIGHT) ||
            (direction === Direction.RIGHT && pendingDirection === Direction.LEFT);

        if (!isOppositeDirection) {
            currentMoveDirection = pendingDirection;
            setDirection(pendingDirection);
        }
        setPendingDirection(null); 
    }

    setSnakeSegments(prevSnake => {
      const newSnake = [...prevSnake];
      const head = { ...newSnake[0] };

      switch (currentMoveDirection) {
        case Direction.UP: head.y -= 1; break;
        case Direction.DOWN: head.y += 1; break;
        case Direction.LEFT: head.x -= 1; break;
        case Direction.RIGHT: head.x += 1; break;
      }

      if (head.x < 0) head.x = currentConfig.boardSize - 1;
      if (head.x >= currentConfig.boardSize) head.x = 0;
      if (head.y < 0) head.y = currentConfig.boardSize - 1;
      if (head.y >= currentConfig.boardSize) head.y = 0;

      for (let i = 1; i < newSnake.length; i++) {
        if (newSnake[i].x === head.x && newSnake[i].y === head.y) {
          setGameState(GameState.GameOver);
          updateHighScore();
          return prevSnake;
        }
      }
      
      if (obstacles.some(obstacle => obstacle.x === head.x && obstacle.y === head.y)) {
        setGameState(GameState.GameOver);
        updateHighScore();
        return prevSnake;
      }

      newSnake.unshift(head);

      if (head.x === foodPosition.x && head.y === foodPosition.y) {
        const newScore = score + 1;
        setScore(newScore);

        if (newScore % currentConfig.scoreToIncreaseSpeed === 0 && newScore > 0) {
            setCurrentConfig(prevConf => ({
                ...prevConf,
                initialSpeed: Math.max(MIN_SPEED, prevConf.initialSpeed * prevConf.speedIncrementFactor)
            }));
        }
        
        if (gameLevel === 1 && newScore >= currentConfig.scoreToReachLevel2 && currentConfig.obstaclePositions.length > 0) {
            setIsTransitioningLevel(true);
            const newObstacles = currentConfig.obstaclePositions; // These are already filtered by board size
            
            const timeoutId = setTimeout(() => {
              setGameLevel(2);
              setObstacles(newObstacles);
              if (newObstacles.some(obs => obs.x === foodPosition.x && obs.y === foodPosition.y)) {
                 setFoodPosition(generateRandomFoodPosition(newSnake, currentConfig.boardSize, newObstacles));
              }
              setIsTransitioningLevel(false);
              setTransitionTimeoutId(null);
            }, 1500);
            setTransitionTimeoutId(timeoutId);
        }
        setFoodPosition(generateRandomFoodPosition(newSnake, currentConfig.boardSize, gameLevel === 2 || isTransitioningLevel ? obstacles : [] ));

      } else {
        newSnake.pop(); 
      }
      return newSnake;
    });
  }, [gameState, direction, foodPosition, score, updateHighScore, pendingDirection, currentConfig, obstacles, gameLevel, isTransitioningLevel]);

  useEffect(() => {
    if (gameState !== GameState.Playing || isTransitioningLevel) {
      if (transitionTimeoutId && gameState !== GameState.Playing) { 
          clearTimeout(transitionTimeoutId);
          setTransitionTimeoutId(null);
          setIsTransitioningLevel(false); 
      }
      return;
    }
    const gameInterval = setInterval(moveSnake, currentConfig.initialSpeed); // Use speed from currentConfig
    return () => clearInterval(gameInterval);
  }, [gameState, moveSnake, currentConfig.initialSpeed, isTransitioningLevel, transitionTimeoutId]);

  const handleKeyPress = useCallback((event: KeyboardEvent) => {
    const key = event.key.toLowerCase();
    
    if (isTransitioningLevel) { 
        if (key === 'p') event.preventDefault(); 
        return;
    }

    const newDirection = ARROW_KEYS_MAP[key];

    if (newDirection !== undefined) {
      event.preventDefault(); 
      if (gameState === GameState.Playing) {
        setPendingDirection(newDirection);
      }
    }

    if (key === 'p') {
      event.preventDefault();
      if (gameState === GameState.Playing) {
        pauseGame();
      } else if (gameState === GameState.Paused) {
        resumeGame();
      }
    }
  }, [gameState, pauseGame, resumeGame, isTransitioningLevel]);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyPress);
    return () => {
      window.removeEventListener('keydown', handleKeyPress);
       if (transitionTimeoutId) clearTimeout(transitionTimeoutId); 
    };
  }, [handleKeyPress, transitionTimeoutId]);

  const restartGame = useCallback(() => {
    if (transitionTimeoutId) clearTimeout(transitionTimeoutId);
    setIsTransitioningLevel(false);
    // Restart with the exact last configuration
    internalResetGame(currentConfig);
    setGameState(GameState.Playing);
  }, [internalResetGame, currentConfig, transitionTimeoutId]);

  return {
    snakeSegments,
    foodPosition,
    gameState,
    score,
    highScore,
    startGame,
    restartGame, 
    boardSize: currentConfig.boardSize, // boardSize from currentConfig
    resumeGame,
    currentDifficultyLevelName: currentConfig.levelName, // levelName from currentConfig
    obstacles,
    isTransitioningLevel,
    gameLevel,
    currentConfig // expose currentConfig for UI display if needed
  };
};
