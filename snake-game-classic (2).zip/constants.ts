import { Direction, DifficultyLevel, DifficultySettings, Position } from './types';

export const DEFAULT_PRESET_BOARD_SIZE = 30; // Board size for which presets (especially obstacles) are designed.
export const MIN_SPEED = 50; // Minimum interval in ms (fastest speed)

// Visuals
export const SNAKE_COLOR = "bg-green-500";
export const SNAKE_HEAD_COLOR = "bg-green-600";
export const FOOD_COLOR = "bg-red-500";
export const OBSTACLE_COLOR = "bg-gray-500";
export const BOARD_CELL_COLOR = "bg-gray-700";
export const BOARD_BACKGROUND_COLOR = "bg-gray-800";
export const TEXT_COLOR = "text-white";
export const BORDER_COLOR = "border-gray-600";
export const BOARD_OUTLINE_COLOR = "border-gray-500";

export const ARROW_KEYS_MAP: { [key: string]: Direction } = {
  arrowup: Direction.UP,
  arrowdown: Direction.DOWN,
  arrowleft: Direction.LEFT,
  arrowright: Direction.RIGHT,
  w: Direction.UP,
  s: Direction.DOWN,
  a: Direction.LEFT,
  d: Direction.RIGHT,
};

// INITIAL_SNAKE_POSITION is now calculated dynamically based on boardSize in useGameLogic.

export const INITIAL_DIRECTION = Direction.RIGHT;
export const HIGH_SCORE_STORAGE_KEY = "snakeGameHighScore";

export const DIFFICULTY_LEVELS = {
  EASY: DifficultyLevel.Easy,
  MEDIUM: DifficultyLevel.Medium,
  HARD: DifficultyLevel.Hard,
};

export const DEFAULT_DIFFICULTY = DifficultyLevel.Medium; // Base for custom games if not specified

// UI Options
export const SELECTABLE_BOARD_SIZES: number[] = [15, 20, 25, DEFAULT_PRESET_BOARD_SIZE];
export const DEFAULT_CUSTOM_BOARD_SIZE = 20;

export interface SpeedOption {
  label: string;
  value: number; // Milliseconds
}
export const SPEED_OPTIONS: SpeedOption[] = [
  { label: "Very Slow", value: 300 },
  { label: "Slow", value: 225 },
  { label: "Normal", value: 150 },
  { label: "Fast", value: 100 },
  { label: "Very Fast", value: 75 },
];
export const DEFAULT_CUSTOM_SPEED_VALUE = 150; // Corresponds to "Normal"

// Difficulty settings define base parameters.
// Obstacles are only applicable if game is run with DEFAULT_PRESET_BOARD_SIZE.
export const DIFFICULTY_SETTINGS_MAP: Record<DifficultyLevel, DifficultySettings> = {
  [DifficultyLevel.Easy]: {
    initialSpeed: 200, // Default speed for Easy preset with DEFAULT_PRESET_BOARD_SIZE
    speedIncrementFactor: 0.96,
    scoreToIncreaseSpeed: 7,
    levelName: "Easy",
    scoreToReachLevel2: 10,
    obstaclePositions: [ // These apply if boardSize is DEFAULT_PRESET_BOARD_SIZE
      { x: 5, y: 15 }, { x: 6, y: 15 },
      { x: 23, y: 15 }, { x: 24, y: 15 },
    ],
  },
  [DifficultyLevel.Medium]: {
    initialSpeed: 150,
    speedIncrementFactor: 0.93,
    scoreToIncreaseSpeed: 5,
    levelName: "Medium",
    scoreToReachLevel2: 8,
    obstaclePositions: [
      { x: 7, y: 7 }, { x: 8, y: 7 }, { x: 9, y: 7 }, { x: 10, y: 7 },
      { x: 19, y: 22 }, { x: 20, y: 22 }, { x: 21, y: 22 }, { x: 22, y: 22 },
    ],
  },
  [DifficultyLevel.Hard]: {
    initialSpeed: 100,
    speedIncrementFactor: 0.90,
    scoreToIncreaseSpeed: 3,
    levelName: "Hard",
    scoreToReachLevel2: 5,
    obstaclePositions: [
      { x: 14, y: 5 }, { x: 15, y: 5 }, { x: 14, y: 24 }, { x: 15, y: 24 },
      { x: 5, y: 14 }, { x: 5, y: 15 }, { x: 24, y: 14 }, { x: 24, y: 15 },
      { x: 10, y: 10 }, { x: 19, y: 10 }, { x: 10, y: 19 }, { x: 19, y: 19 }
    ],
  },
};
