import React from 'react';
import Board from './components/Board';
import ScoreDisplay from './components/ScoreDisplay';
import GameOverModal from './components/GameOverModal';
import StartScreen from './components/StartScreen';
import PauseScreen from './components/PauseScreen';
import { useGameLogic } from './hooks/useGameLogic';
import { GameState } from './types'; 
import { TEXT_COLOR } from './constants';

const App: React.FC = () => {
  const {
    snakeSegments,
    foodPosition,
    gameState,
    score,
    highScore,
    startGame, // This is now the new startGame function
    restartGame,
    boardSize, // Now dynamically from useGameLogic
    resumeGame,
    currentDifficultyLevelName, // Can be "Custom"
    obstacles,
    isTransitioningLevel,
    gameLevel,
    currentConfig, // For potential display, not directly used in rendering here
  } = useGameLogic();

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-900 text-white p-2 sm:p-4 select-none">
      <header className="my-3 sm:my-4 text-center">
        <h1 className="text-3xl sm:text-4xl font-extrabold tracking-wider text-green-400">
          SNAKE <span className="text-teal-400">CLASSIC</span>
        </h1>
      </header>

      <ScoreDisplay 
        score={score} 
        highScore={highScore} 
        difficultyName={(gameState === GameState.Playing || gameState === GameState.Paused || gameState === GameState.GameOver) ? currentDifficultyLevelName : undefined}
        gameLevel={(gameState === GameState.Playing || gameState === GameState.Paused || gameState === GameState.GameOver) ? gameLevel : undefined}
      />

      <div className="relative shadow-2xl"> {/* Container for board and overlays */}
        <Board
          snakeSegments={snakeSegments}
          foodPosition={foodPosition}
          obstacles={obstacles}
          boardSize={boardSize} // Dynamic board size
        />
        {gameState === GameState.NotStarted && <StartScreen onStartGame={startGame} />}
        {gameState === GameState.GameOver && (
          <GameOverModal 
            score={score} 
            onRestart={restartGame} 
            onStartNewGame={startGame} // Pass new startGame
            currentPlayedDifficultyName={currentDifficultyLevelName} 
          />
        )}
        {gameState === GameState.Paused && !isTransitioningLevel && <PauseScreen onResumeGame={resumeGame} />}
        {isTransitioningLevel && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black bg-opacity-75 backdrop-blur-sm z-20 p-4 text-center rounded-md">
            <h2 className={`text-3xl sm:text-4xl font-bold mb-3 ${TEXT_COLOR} animate-bounce`}>Level {gameLevel}!</h2>
           { currentConfig?.obstaclePositions && currentConfig.obstaclePositions.length > 0 &&
             <p className={`text-lg sm:text-xl ${TEXT_COLOR}`}>Get Ready for Obstacles!</p>
           }
           { (!currentConfig?.obstaclePositions || currentConfig.obstaclePositions.length === 0) && gameLevel === 2 &&
              <p className={`text-lg sm:text-xl ${TEXT_COLOR}`}>Advancing!</p> // Message if no obstacles for level 2 (e.g. custom board)
           }
          </div>
        )}
      </div>

      <footer className="mt-4 sm:mt-6 text-center text-gray-400 text-xs sm:text-sm">
        <p>Use Arrow Keys or W,A,S,D to move. Press 'P' to Pause/Resume.</p>
        <p className="mt-1">Crafted with React, TypeScript, & Tailwind CSS.</p>
      </footer>
    </div>
  );
};

export default App;
