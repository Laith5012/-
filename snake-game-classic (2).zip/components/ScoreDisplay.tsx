import React from 'react';
import { TEXT_COLOR } from '../constants';

interface ScoreDisplayProps {
  score: number;
  highScore: number;
  difficultyName?: string;
  gameLevel?: number;
}

const ScoreDisplay: React.FC<ScoreDisplayProps> = ({ score, highScore, difficultyName, gameLevel }) => {
  return (
    <div className={`p-3 px-6 rounded-lg shadow-md bg-gray-700 ${TEXT_COLOR} flex flex-col sm:flex-row justify-between items-center w-full max-w-md mb-5 gap-2 sm:gap-4`}>
      <div className="text-lg sm:text-xl">
        Score: <span className="font-bold text-green-400 tabular-nums">{score}</span>
      </div>
      <div className="flex flex-col items-center">
        {difficultyName && (
          <div className="text-xs sm:text-sm text-yellow-300">
            Difficulty: <span className="font-semibold">{difficultyName}</span>
          </div>
        )}
        {gameLevel !== undefined && (
           <div className="text-xs sm:text-sm text-cyan-300">
            Level: <span className="font-semibold">{gameLevel}</span>
          </div>
        )}
      </div>
      <div className="text-lg sm:text-xl">
        High Score: <span className="font-bold text-yellow-400 tabular-nums">{highScore}</span>
      </div>
    </div>
  );
};

export default ScoreDisplay;