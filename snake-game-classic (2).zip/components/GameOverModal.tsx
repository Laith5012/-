import React, { useState, useEffect } from 'react';
import { TEXT_COLOR, DIFFICULTY_LEVELS, DIFFICULTY_SETTINGS_MAP, SELECTABLE_BOARD_SIZES, SPEED_OPTIONS, DEFAULT_CUSTOM_BOARD_SIZE, DEFAULT_CUSTOM_SPEED_VALUE, DEFAULT_DIFFICULTY, DEFAULT_PRESET_BOARD_SIZE } from '../constants';
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { DifficultyLevel } from '../types';
import { StartGameParams } from '../hooks/useGameLogic';

interface GameOverModalProps {
  score: number;
  onRestart: () => void; // Restarts with the exact last used settings
  onStartNewGame: (params: StartGameParams) => void; 
  currentPlayedDifficultyName?: string; // Name of the difficulty/config just played
}

const GameOverModal: React.FC<GameOverModalProps> = ({ score, onRestart, onStartNewGame, currentPlayedDifficultyName }) => {
  const [geminiMessage, setGeminiMessage] = useState<string | null>(null);
  const [isLoadingGemini, setIsLoadingGemini] = useState<boolean>(false);

  const [showCustomSettings, setShowCustomSettings] = useState(false);
  const [customBoardSize, setCustomBoardSize] = useState<number>(DEFAULT_CUSTOM_BOARD_SIZE);
  const [customSpeed, setCustomSpeed] = useState<number>(DEFAULT_CUSTOM_SPEED_VALUE);
  const [baseDifficultyForCustom, setBaseDifficultyForCustom] = useState<DifficultyLevel>(DEFAULT_DIFFICULTY);

  useEffect(() => {
    if (typeof score === 'number') { 
      const fetchGeminiAnalysis = async () => {
        setIsLoadingGemini(true);
        setGeminiMessage(null); 

        if (!process.env.API_KEY) {
          setGeminiMessage("Good game! Try to beat your high score next time.");
          setIsLoadingGemini(false);
          return;
        }

        try {
          const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
          const prompt = `My score in a Snake game was ${score}${currentPlayedDifficultyName ? ` on ${currentPlayedDifficultyName} settings` : ''}. Give me a short (1-2 sentences) playful, game-themed comment, as if you are a game announcer. Examples: Score 0: "Ouch, zero points! Try to grab just one apple next time!" Score 5: "Nice one, 5 points! Keep gobbling those apples!" Score 15: "Sweet 15 points! You're really slithering smoothly!" Score 25: "Wow, 25 points! You're a Snake superstar! Can you make a cool pattern next?" The comment should be direct and encouraging. Avoid markdown.`;

          const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash-preview-04-17',
            contents: prompt,
          });
          
          let message = response.text.trim();
          const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
          const match = message.match(fenceRegex);
          if (match && match[2]) {
            message = match[2].trim();
          }
          setGeminiMessage(message);

        } catch (error) {
          console.error("Error fetching Gemini analysis:", error);
          setGeminiMessage("Great game! Keep trying to beat your high score!"); 
        } finally {
          setIsLoadingGemini(false);
        }
      };
      fetchGeminiAnalysis();
    }
  }, [score, currentPlayedDifficultyName]);

  const presetDifficultyButtons = [
    { level: DIFFICULTY_LEVELS.EASY, label: DIFFICULTY_SETTINGS_MAP[DIFFICULTY_LEVELS.EASY].levelName, color: "bg-green-500 hover:bg-green-600", ringColor: "focus:ring-green-400" },
    { level: DIFFICULTY_LEVELS.MEDIUM, label: DIFFICULTY_SETTINGS_MAP[DIFFICULTY_LEVELS.MEDIUM].levelName, color: "bg-yellow-500 hover:bg-yellow-600", ringColor: "focus:ring-yellow-400" },
    { level: DIFFICULTY_LEVELS.HARD, label: DIFFICULTY_SETTINGS_MAP[DIFFICULTY_LEVELS.HARD].levelName, color: "bg-red-500 hover:bg-red-600", ringColor: "focus:ring-red-400" },
  ];

  const handleStartPreset = (difficulty: DifficultyLevel) => {
    onStartNewGame({ difficulty });
    setShowCustomSettings(false);
  };

  const handleStartCustom = () => {
    onStartNewGame({
      difficulty: baseDifficultyForCustom,
      customBoardSize: customBoardSize,
      customInitialSpeed: customSpeed,
    });
    setShowCustomSettings(false);
  };
  
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center bg-black bg-opacity-80 backdrop-blur-sm z-10 p-3 text-center rounded-md overflow-auto">
      <h2 className={`text-3xl sm:text-4xl font-bold mb-1 ${TEXT_COLOR}`}>Game Over!</h2>
      {currentPlayedDifficultyName && <p className={`text-sm sm:text-md mb-1 ${TEXT_COLOR}`}>Played on: <span className="font-semibold text-yellow-300">{currentPlayedDifficultyName}</span></p>}
      <p className={`text-lg sm:text-xl mb-1 ${TEXT_COLOR}`}>Your Score: <span className="font-bold text-green-400 tabular-nums">{score}</span></p>
      
      <div className="my-1 text-xs sm:text-sm text-cyan-300 min-h-[2em] sm:min-h-[2.5em] px-2 w-full max-w-xs sm:max-w-sm">
        {isLoadingGemini && <p className="animate-pulse italic">Getting some feedback for you...</p>}
        {!isLoadingGemini && geminiMessage && <p className="italic">"{geminiMessage}"</p>}
        {!isLoadingGemini && !geminiMessage && process.env.API_KEY && <p className="italic text-gray-400">No special comment this time, but good job!</p>}
        {!isLoadingGemini && !geminiMessage && !process.env.API_KEY && <p className="italic text-gray-500 text-xs">(Dynamic feedback disabled)</p>}
      </div>

      <button
        onClick={onRestart}
        className="mt-1 px-5 py-2 sm:px-6 sm:py-2.5 bg-blue-500 hover:bg-blue-600 text-white text-md sm:text-lg font-bold rounded-lg shadow-xl transform hover:scale-105 transition-transform duration-150 focus:outline-none focus:ring-4 focus:ring-blue-400 focus:ring-opacity-50"
        aria-label={`Restart Game with current settings`}
      >
        Restart (Current Settings)
      </button>

      <div className="mt-3 w-full max-w-md">
        <p className={`${TEXT_COLOR} text-sm mb-1`}>Or start new game:</p>
        {!showCustomSettings && (
          <>
            <div className="grid grid-cols-3 gap-2 mb-2">
              {presetDifficultyButtons.map(({level, label, color, ringColor}) => (
                 <button
                    key={label}
                    onClick={() => handleStartPreset(level)}
                    className={`px-2 py-1.5 ${color} text-white text-xs font-semibold rounded-md shadow-md transform hover:scale-105 transition-transform duration-150 focus:outline-none focus:ring-2 ${ringColor} focus:ring-opacity-60`}
                 >
                   {label}
                 </button>
              ))}
            </div>
            <button
              onClick={() => setShowCustomSettings(true)}
              className={`px-3 py-1.5 bg-cyan-600 hover:bg-cyan-700 ${TEXT_COLOR} text-xs font-semibold rounded-md shadow-md focus:outline-none focus:ring-2 focus:ring-cyan-400`}
            >
              Customize...
            </button>
          </>
        )}

        {showCustomSettings && (
          <div className="w-full p-2 bg-gray-700 rounded-lg shadow-lg">
            <h3 className={`${TEXT_COLOR} text-md font-semibold mb-2`}>Custom Settings</h3>
             <div className="mb-2">
              <label htmlFor="goBaseDifficulty" className={`block text-xs font-medium ${TEXT_COLOR} mb-0.5`}>Base Difficulty:</label>
              <select
                id="goBaseDifficulty"
                value={baseDifficultyForCustom}
                onChange={(e) => setBaseDifficultyForCustom(Number(e.target.value) as DifficultyLevel)}
                className="bg-gray-600 border-gray-500 text-white text-xs rounded-md focus:ring-blue-500 focus:border-blue-500 block w-full p-1.5"
              >
                {presetDifficultyButtons.map(d => <option key={d.level} value={d.level}>{d.label}</option>)}
              </select>
            </div>
            <div className="mb-2">
              <label htmlFor="goBoardSize" className={`block text-xs font-medium ${TEXT_COLOR} mb-0.5`}>Board Size:</label>
              <select
                id="goBoardSize"
                value={customBoardSize}
                onChange={(e) => setCustomBoardSize(Number(e.target.value))}
                className="bg-gray-600 border-gray-500 text-white text-xs rounded-md focus:ring-blue-500 focus:border-blue-500 block w-full p-1.5"
              >
                {SELECTABLE_BOARD_SIZES.map(size => <option key={size} value={size}>{size} x {size}</option>)}
              </select>
               {customBoardSize !== DEFAULT_PRESET_BOARD_SIZE && <p className="text-xxs text-yellow-400 mt-0.5">(Level 2 obstacles disabled)</p>}
            </div>
            <div className="mb-2">
              <label htmlFor="goInitialSpeed" className={`block text-xs font-medium ${TEXT_COLOR} mb-0.5`}>Initial Speed: {SPEED_OPTIONS.find(opt => opt.value === customSpeed)?.label}</label>
              <input
                id="goInitialSpeed" type="range" min={SPEED_OPTIONS[SPEED_OPTIONS.length -1].value} max={SPEED_OPTIONS[0].value} step="25"
                value={customSpeed} onChange={(e) => setCustomSpeed(Number(e.target.value))}
                className="w-full h-1.5 bg-gray-500 rounded-lg appearance-none cursor-pointer accent-green-500"
              />
            </div>
            <div className="flex gap-2 mt-2">
               <button onClick={handleStartCustom} className="flex-1 px-3 py-1.5 bg-green-500 hover:bg-green-600 text-white text-xs font-bold rounded-md shadow-md">Start Custom</button>
               <button onClick={() => setShowCustomSettings(false)} className="flex-1 px-3 py-1.5 bg-gray-500 hover:bg-gray-600 text-white text-xs font-semibold rounded-md shadow-md">Back</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default GameOverModal;
