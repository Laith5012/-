import React from 'react';
import { SnakeSegment, Food, Position } from '../types';
import { SNAKE_COLOR, SNAKE_HEAD_COLOR, FOOD_COLOR, OBSTACLE_COLOR, BOARD_CELL_COLOR, BOARD_OUTLINE_COLOR, BORDER_COLOR, BOARD_BACKGROUND_COLOR } from '../constants';

interface BoardProps {
  snakeSegments: SnakeSegment[];
  foodPosition: Food;
  obstacles: Position[];
  boardSize: number;
}

const Board: React.FC<BoardProps> = ({ snakeSegments, foodPosition, obstacles, boardSize }) => {
  const cells = [];
  const head = snakeSegments[0];

  for (let y = 0; y < boardSize; y++) {
    for (let x = 0; x < boardSize; x++) {
      const isHead = head?.x === x && head?.y === y;
      const isSnakeSegment = snakeSegments.some(segment => segment.x === x && segment.y === y);
      const isFood = foodPosition.x === x && foodPosition.y === y;
      const isObstacle = obstacles.some(obstacle => obstacle.x === x && obstacle.y === y);

      let cellClasses = `w-5 h-5 ${BORDER_COLOR}`; 

      if (isHead) {
        cellClasses += ` ${SNAKE_HEAD_COLOR} rounded-sm`;
      } else if (isSnakeSegment) {
        cellClasses += ` ${SNAKE_COLOR} rounded-sm`;
      } else if (isFood) {
        cellClasses += ` ${FOOD_COLOR} rounded-full`;
      } else if (isObstacle) {
        cellClasses += ` ${OBSTACLE_COLOR} rounded-xs shadow-inner`; // Obstacles style
      } else {
        cellClasses += ` ${BOARD_CELL_COLOR}`;
      }
      
      cells.push(
        <div
          key={`${x}-${y}`}
          className={cellClasses}
          style={{ gridColumnStart: x + 1, gridRowStart: y + 1 }}
          aria-label={isObstacle ? "Obstacle" : isFood ? "Food" : isSnakeSegment ? "Snake segment" : "Empty cell"}
        />
      );
    }
  }
  
  const boardPixelSize = boardSize * 20; 

  return (
    <div 
      className={`grid border-2 ${BOARD_OUTLINE_COLOR} shadow-2xl ${BOARD_BACKGROUND_COLOR} rounded-md`}
      style={{
        gridTemplateColumns: `repeat(${boardSize}, minmax(0, 1fr))`,
        gridTemplateRows: `repeat(${boardSize}, minmax(0, 1fr))`,
        width: `${boardPixelSize}px`,
        height: `${boardPixelSize}px`,
      }}
      role="grid"
      aria-readonly="true"
      aria-label={`Snake game board, ${boardSize} by ${boardSize} cells`}
    >
      {cells}
    </div>
  );
};

export default Board;