import React, { useState } from 'react';
import { TEXT_COLOR, DIFFICULTY_LEVELS, DIFFICULTY_SETTINGS_MAP, SELECTABLE_BOARD_SIZES, SPEED_OPTIONS, DEFAULT_CUSTOM_BOARD_SIZE, DEFAULT_CUSTOM_SPEED_VALUE, DEFAULT_DIFFICULTY, DEFAULT_PRESET_BOARD_SIZE } from '../constants';
import { DifficultyLevel } from '../types';
import { StartGameParams } from '../hooks/useGameLogic';


interface StartScreenProps {
  onStartGame: (params: StartGameParams) => void;
}

const StartScreen: React.FC<StartScreenProps> = ({ onStartGame }) => {
  const [showCustomSettings, setShowCustomSettings] = useState(false);
  const [customBoardSize, setCustomBoardSize] = useState<number>(DEFAULT_CUSTOM_BOARD_SIZE);
  const [customSpeed, setCustomSpeed] = useState<number>(DEFAULT_CUSTOM_SPEED_VALUE);
  const [baseDifficultyForCustom, setBaseDifficultyForCustom] = useState<DifficultyLevel>(DEFAULT_DIFFICULTY);

  const presetDifficultyButtons = [
    { level: DIFFICULTY_LEVELS.EASY, label: DIFFICULTY_SETTINGS_MAP[DIFFICULTY_LEVELS.EASY].levelName, color: "bg-green-500 hover:bg-green-600", ringColor: "focus:ring-green-400" },
    { level: DIFFICULTY_LEVELS.MEDIUM, label: DIFFICULTY_SETTINGS_MAP[DIFFICULTY_LEVELS.MEDIUM].levelName, color: "bg-yellow-500 hover:bg-yellow-600", ringColor: "focus:ring-yellow-400" },
    { level: DIFFICULTY_LEVELS.HARD, label: DIFFICULTY_SETTINGS_MAP[DIFFICULTY_LEVELS.HARD].levelName, color: "bg-red-500 hover:bg-red-600", ringColor: "focus:ring-red-400" },
  ];

  const handleStartPreset = (difficulty: DifficultyLevel) => {
    onStartGame({ difficulty }); // No custom params, implies default board size and speed for preset
  };

  const handleStartCustom = () => {
    onStartGame({
      difficulty: baseDifficultyForCustom,
      customBoardSize: customBoardSize,
      customInitialSpeed: customSpeed,
    });
  };

  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center bg-black bg-opacity-70 backdrop-blur-sm z-10 p-4 text-center rounded-md overflow-auto">
      <h1 className={`text-4xl sm:text-5xl font-bold mb-3 ${TEXT_COLOR} animate-pulse`}>Snake Classic</h1>
      
      {!showCustomSettings && (
        <>
          <p className={`${TEXT_COLOR} mb-4 text-lg sm:text-xl`}>Select Difficulty:</p>
          <div className="space-y-3 sm:space-y-0 sm:space-x-3 flex flex-col sm:flex-row mb-4">
            {presetDifficultyButtons.map(({ level, label, color, ringColor }) => (
              <button
                key={level}
                onClick={() => handleStartPreset(level)}
                className={`px-4 py-2 sm:px-5 sm:py-2.5 ${color} text-white text-md sm:text-lg font-bold rounded-lg shadow-xl transform hover:scale-105 transition-transform duration-150 focus:outline-none focus:ring-4 ${ringColor} focus:ring-opacity-50 w-full sm:w-auto min-w-[110px]`}
              >
                {label}
              </button>
            ))}
          </div>
          <button
            onClick={() => setShowCustomSettings(true)}
            className={`mt-2 px-4 py-2 bg-cyan-600 hover:bg-cyan-700 ${TEXT_COLOR} text-md font-semibold rounded-lg shadow-md focus:outline-none focus:ring-2 focus:ring-cyan-400`}
          >
            Customize Settings...
          </button>
        </>
      )}

      {showCustomSettings && (
        <div className="w-full max-w-md p-3 bg-gray-800 rounded-lg shadow-xl">
          <h2 className={`${TEXT_COLOR} text-xl font-semibold mb-3`}>Custom Game Settings</h2>
          
          <div className="mb-3">
            <label htmlFor="baseDifficulty" className={`block text-sm font-medium ${TEXT_COLOR} mb-1`}>Base Difficulty (for speed scaling, etc.):</label>
            <select
              id="baseDifficulty"
              value={baseDifficultyForCustom}
              onChange={(e) => setBaseDifficultyForCustom(Number(e.target.value) as DifficultyLevel)}
              className="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2"
            >
              {presetDifficultyButtons.map(d => <option key={d.level} value={d.level}>{d.label}</option>)}
            </select>
          </div>

          <div className="mb-3">
            <label htmlFor="boardSize" className={`block text-sm font-medium ${TEXT_COLOR} mb-1`}>Board Size:</label>
            <select
              id="boardSize"
              value={customBoardSize}
              onChange={(e) => setCustomBoardSize(Number(e.target.value))}
              className="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2"
            >
              {SELECTABLE_BOARD_SIZES.map(size => <option key={size} value={size}>{size} x {size}</option>)}
            </select>
            {customBoardSize !== DEFAULT_PRESET_BOARD_SIZE && <p className="text-xs text-yellow-400 mt-1">Level 2 obstacles are disabled for custom board sizes.</p>}
          </div>

          <div className="mb-4">
            <label htmlFor="initialSpeed" className={`block text-sm font-medium ${TEXT_COLOR} mb-1`}>Initial Speed: {SPEED_OPTIONS.find(opt => opt.value === customSpeed)?.label}</label>
            <input
              id="initialSpeed"
              type="range"
              min={SPEED_OPTIONS[SPEED_OPTIONS.length -1].value} // Fastest
              max={SPEED_OPTIONS[0].value} // Slowest
              step="25" // Adjust step as needed, most options are 25/50 apart
              value={customSpeed}
              onChange={(e) => setCustomSpeed(Number(e.target.value))}
              className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer accent-green-500"
            />
             <div className="flex justify-between text-xs text-gray-400 mt-1 px-1">
              <span>Fast</span>
              <span>Slow</span>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-2">
            <button
                onClick={handleStartCustom}
                className="flex-1 px-5 py-2.5 bg-green-500 hover:bg-green-600 text-white text-lg font-bold rounded-lg shadow-xl transform hover:scale-105 transition-transform duration-150 focus:outline-none focus:ring-4 focus:ring-green-400 focus:ring-opacity-50"
            >
                Start Custom Game
            </button>
            <button
                onClick={() => setShowCustomSettings(false)}
                className="flex-1 px-4 py-2 bg-gray-500 hover:bg-gray-600 ${TEXT_COLOR} text-md font-semibold rounded-lg shadow-md focus:outline-none focus:ring-2 focus:ring-gray-400"
            >
                Back to Presets
            </button>
          </div>
        </div>
      )}

      <div className={`${TEXT_COLOR} mt-4 text-sm sm:text-base space-y-1`}>
        <p>Use <kbd className="px-2 py-1 text-xs font-semibold text-gray-800 bg-gray-100 border border-gray-200 rounded-lg">Arrow Keys</kbd> or <kbd className="px-2 py-1 text-xs font-semibold text-gray-800 bg-gray-100 border border-gray-200 rounded-lg">W</kbd> <kbd className="px-2 py-1 text-xs font-semibold text-gray-800 bg-gray-100 border border-gray-200 rounded-lg">S</kbd> <kbd className="px-2 py-1 text-xs font-semibold text-gray-800 bg-gray-100 border border-gray-200 rounded-lg">D</kbd> to move.</p>
        <p>Press <kbd className="px-2 py-1 text-xs font-semibold text-gray-800 bg-gray-100 border border-gray-200 rounded-lg">P</kbd> to Pause/Resume.</p>
      </div>
    </div>
  );
};

export default StartScreen;
