
import React from 'react';
import { TEXT_COLOR } from '../constants';

interface PauseScreenProps {
  onResumeGame: () => void;
}

const PauseScreen: React.FC<PauseScreenProps> = ({ onResumeGame }) => {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center bg-black bg-opacity-70 backdrop-blur-sm z-10 p-4 text-center rounded-md">
      <h2 className={`text-3xl sm:text-4xl font-bold mb-5 sm:mb-6 ${TEXT_COLOR}`}>Paused</h2>
      <button
        onClick={onResumeGame}
        className="px-6 py-3 sm:px-8 sm:py-4 bg-yellow-500 hover:bg-yellow-600 text-black text-xl sm:text-2xl font-bold rounded-lg shadow-xl transform hover:scale-105 transition-transform duration-150 focus:outline-none focus:ring-4 focus:ring-yellow-400 focus:ring-opacity-50"
      >
        Resume
      </button>
      <p className={`${TEXT_COLOR} mt-6 text-sm sm:text-base`}>Press <kbd className="px-2 py-1 text-xs font-semibold text-gray-800 bg-gray-100 border border-gray-200 rounded-lg">P</kbd> to Resume.</p>
    </div>
  );
};

export default PauseScreen;
