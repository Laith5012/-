export interface Position {
  x: number;
  y: number;
}

export enum Direction {
  UP,
  DOWN,
  LEFT,
  RIGHT,
}

export enum GameState {
  NotStarted,
  Playing,
  Paused,
  GameOver,
}

export interface SnakeSegment extends Position {}

export interface Food extends Position {}

export enum DifficultyLevel {
  Easy,
  Medium,
  Hard,
}

// Represents the base settings for a difficulty preset.
// Actual game might override initialSpeed or use a different boardSize.
export interface DifficultySettings {
  initialSpeed: number; // Default initial speed for this preset
  speedIncrementFactor: number;
  scoreToIncreaseSpeed: number;
  levelName: string; // Name of the preset, e.g., "Easy", "Medium", "Hard"
  scoreToReachLevel2: number; // Score to reach level 2 if using DEFAULT_PRESET_BOARD_SIZE
  obstaclePositions: Position[]; // Obstacles defined for DEFAULT_PRESET_BOARD_SIZE
}

// Represents the fully resolved configuration for the current game instance
export interface GameConfig extends DifficultySettings {
  boardSize: number;
  // initialSpeed is already in DifficultySettings, will be the actual used speed.
  // levelName can be "Custom" if boardSize or initialSpeed were overridden.
}
